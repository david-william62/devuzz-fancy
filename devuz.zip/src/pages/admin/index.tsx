import React, { useState } from "react";
import "./index.css";

function Admin() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [name, setName] = useState<string>("");
  const [price, setPrice] = useState<string>("");
  const [uploading, setUploading] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];

    if (selectedFile) {
      setFile(selectedFile);

      // Create a FileReader to show a preview of the image
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleUpload = async () => {
    if (!file || !name || !price) {
      setError("All fields are required.");
      return;
    }

    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append("image", file);
      formData.append("name", name);
      formData.append("price", price);

      const response = await fetch("http://localhost:3000/db-post", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to upload item.");
      }

      const data = await response.json();
      console.log("Item uploaded successfully:", data);

      setUploading(false);
      setProgress(0);
      setFile(null);
      setPreview(null);
      setName("");
      setPrice("");
    } catch (error) {
      setUploading(false);
      setError("An error occurred while uploading.");
      console.error(error);
    }
  };

  return (
    <div className="admin-wrapper">
      <div className="upload-ui">
        {preview && (
          <img src={preview} alt="Preview" className="image-preview" />
        )}
        <input
          type="file"
          name="image"
          id="inp1"
          placeholder="Upload image"
          onChange={handleFileChange}
        />
        <input
          type="text"
          name="Name"
          id="inp2"
          placeholder="Name of item"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          name="Price"
          id="inp3"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
        <button
          onClick={handleUpload}
          disabled={uploading}
          className="upload-btn"
        >
          {uploading ? `Uploading... ${Math.round(progress)}%` : "Upload Item"}
        </button>
        {error && <p className="error-message">{error}</p>}
      </div>
    </div>
  );
}

export { Admin };
