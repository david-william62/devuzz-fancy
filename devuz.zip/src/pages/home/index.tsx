function Home() {
  return (
    <div className="home-wrapper">
      <div></div>
    </div>
  );
}

export { Home };
