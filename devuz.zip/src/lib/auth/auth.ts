import { Account, Client } from "appwrite";

class Appwrite {
  client: Client;
  account: Account;

  constructor() {
    this.client = new Client()
      .setEndpoint("https://cloud.appwrite.io/v1")
      .setProject("66d81002003d2e1976b5");
    this.account = new Account(this.client);
  }

  async login(email: string, pass: string) {
    const res = this.account.create("admin0", email, pass);
    return res;
  }
}

export const appwrite = new Appwrite();
