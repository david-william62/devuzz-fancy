import "./index.css";
import { user } from "../../App";
import config from "../../config.json";

function Header() {
  const sendMail = () => {
    const url = user.getMailUrl(config.mail);
    window.location.href = url;
  };
  return (
    <header>
      <div className="logo"></div>
      <div className="navs">
        <button onClick={sendMail} className="contact-btn">
          Contact Us
        </button>
      </div>
    </header>
  );
}

export { Header };
