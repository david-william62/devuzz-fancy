import express, { Request, Response } from "express";
import multer from "multer";
import { db, storage } from "../src/lib";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { addDoc, collection } from "firebase/firestore";

const app = express();
const port = 3000;

// Configure Multer for file uploads
const upload = multer({ storage: multer.memoryStorage() });

// Middleware to parse JSON requests
app.use(express.json());

// Route to handle posting an item
app.post(
  "/db-post",
  upload.single("image"),
  async (req: Request, res: Response) => {
    try {
      const { name, price } = req.body;
      const file = req.file;

      if (!file) {
        return res.status(400).send("No image file uploaded");
      }
      const storageRef = ref(storage, `images/${file.originalname}`);
      await uploadBytes(storageRef, file.buffer);
      const imageUrl = await getDownloadURL(storageRef);

      await addDoc(collection(db, "items"), {
        name,
        price,
        imageUrl,
      });

      res.status(200).send("Item added successfully");
    } catch (error) {
      console.error("Error adding item:", error);
      res.status(500).send("An error occurred while adding the item");
    }
  }
);

app.listen(port, () => {
  console.log(`API listening at http://localhost:${port}`);
});
